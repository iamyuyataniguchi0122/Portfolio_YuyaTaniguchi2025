/******************************************************************************
* stereo.cpp 
*/

#include "platform.h"

#include "common.h"
#include "sim.h"

extern WindowDataT window;
extern SimDataT simdata;

// projview.cpp
void Viewing( void );
void Projection( void );

// cylindrical.cpp
void cylindricalView( float dx );

// main.cpp
void singleView( float d );

/*------------------------------------------------------------------- display
* display - GLUT display callback function
*--------*/
void Stereo( void )
{
	bool quadbuffer = true;
	bool cylindrical = true;
	bool reverse = false;

	float pallarax = 0.00625;

	if( reverse ) pallarax *= -1.0;

	//-------- viewport
	glViewport( 0, 0, window.width, window.height );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	//PreDraw();

	//������摜
	if( quadbuffer )
		glDrawBuffer( GL_BACK_LEFT );
	else
		glColorMask( GL_FALSE, GL_TRUE, GL_TRUE, GL_TRUE ); //�J���[�}�X�NG+B

	glViewport( 0, 0, window.width, window.height );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	/*
	if(reverseflag) cylindricalView( -0.0625 );
	else cylindricalView(  0.0625 );
	*/
	if( cylindrical ) cylindricalView(  0.0625 );
	else singleView( 0.0625 );

	//���E��摜
	if( quadbuffer )
		glDrawBuffer( GL_BACK_RIGHT );
	else
		glColorMask( GL_TRUE, GL_FALSE, GL_FALSE, GL_TRUE ); //�J���[�}�X�NR

	//��anaglyph�̏ꍇ�ɂ̓f�v�X�o�b�t�@�̂݃N���A
	if( ! quadbuffer ) glClear( GL_DEPTH_BUFFER_BIT );
	else{
		glViewport( 0, 0, window.width, window.height );
		glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );			
	}
	/*
	if(reverseflag) cylindricalView(  0.0625 );
	else  cylindricalView( -0.0625 );
	*/
	if( cylindrical ) cylindricalView( -0.0625 );
	else singleView( -0.0625 );

	//���h���[�o�b�t�@(quad)/�J���[�}�X�N(anaglyph)�����ɖ߂�
	if( quadbuffer )
		glDrawBuffer( GL_BACK );
	else
		glColorMask( GL_TRUE,  GL_TRUE, GL_TRUE, GL_TRUE );//�J���[�}�X�N��߂�

	//PostDraw();

	//-------- swapbuffers
	glutSwapBuffers();

	return;
}
/******** end of file ********/
