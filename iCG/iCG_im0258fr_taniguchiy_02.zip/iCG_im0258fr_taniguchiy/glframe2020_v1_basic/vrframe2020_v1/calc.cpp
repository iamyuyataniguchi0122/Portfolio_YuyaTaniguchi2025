#include "platform.h"

#include <math.h>

#include "sim.h"
#include "calc.h"
#include "ezUtil.h"

//float PI = 3.14159;
const float RADIAN = M_PI / 180.0;
const float DEGREE = 180.0 / M_PI;
void setObjPos( ObjDataT *obj, float *pos )
{
	obj->x = pos[0];
	obj->y = pos[1];
	obj->z = pos[2];
}
void setObjRot( ObjDataT *obj, float *rot )
{
	obj->roll =  rot[0];
	obj->pitch = rot[1];
	obj->yaw =   rot[2];
}
void getObjPos( ObjDataT *obj, float *pos )
{
	pos[0] = obj->x;
	pos[1] = obj->y;
	pos[2] = obj->z;
}
void getObjRot( ObjDataT *obj, float *rot )
{
	rot[0] = obj->roll;
	rot[1] = obj->pitch;
	rot[2] = obj->yaw;
}



void setObjColor( ObjDataT *obj, float red, float green, float blue )
{
	obj->red = red;
	obj->green = green;
	obj->blue = blue;
}
void setObjPos( ObjDataT *obj, float x, float y, float z )
{
	obj->x = x;
	obj->y = y;
	obj->z = z;
}
void setObjRot( ObjDataT *obj, float roll, float pitch, float yaw )
{
	obj->roll = roll;
	obj->pitch = pitch;
	obj->yaw = yaw;
}

void copyObj( ObjDataT *src, ObjDataT *dst )
{
	setObjPos( dst, src->x, src->y, src->z );
	setObjRot( dst, src->roll, src->pitch, src->yaw );
	setObjColor( dst, src->red, src->green, src->blue );
#if 0
	dst->base = src->base;
#endif
	dst->radius = src->radius;
	dst->state = src->state;
	dst->visible = src->visible;
	dst->move = src->move;
	dst->turn = src->turn;
	return;
}

//���I�u�W�F�N�ga����I�u�W�F�N�gb�ւ̕����x�N�g�������߂�֐�
//�I�u�W�F�N�g�Ԃ̕����x�N�g��
void DirectionAtoB( ObjDataT *a, ObjDataT *b, vector_t *dir )
{
	dir->x = b->x - a->x;
	dir->y = b->y - a->y;
	dir->z = b->z - a->z;
}
//���x�N�g���̑傫�����v�Z����֐�
//�x�N�g���̑傫��
float VectorNorm( vector_t *v )
{
	return sqrtf( v->x * v->x + v->y * v->y + v->z * v->z );
}
//�����������߂�֐��i�u�Փ˔���v�ō�����֐��̕ʃo�[�W�����j
//�I�u�W�F�N�g�ԋ���
float DistanceAtoB( ObjDataT *a, ObjDataT *b )
{
	vector_t v;
 	DirectionAtoB( a, b, &v );
	return VectorNorm( &v );
}
//�������x�N�g��������ʊp�Ƌp�����߂�֐�
float VectorToPolar( vector_t *v,  euler_t *angle )
{
	float d = sqrtf( v->x * v->x + v->z * v->z );
	angle->pitch = DEGREE * atan2f( v->y, d );
	angle->yaw = DEGREE * atan2f( - v->x, - v->z );
	return VectorNorm( v );
}
//�����ʊp�Ƌp����P�ʕ����x�N�g�������߂�֐�
void PolarToVector( euler_t *angle, vector_t *v)
{
    float rad, l;

	rad = angle->pitch * RADIAN;
	v->y = sinf( rad );
	l = cosf( rad );

	rad = angle->yaw * RADIAN;
	v->x = - l * sinf( rad );
	v->z = - l * cosf( rad );

	return;
}
//���I�u�W�F�N�g�Ԃ̊p�x�ia����b�������ޕ��ʊp�Ƌp�j
float EulerAtoB( ObjDataT *a, ObjDataT *b, euler_t *angle )
{
	vector_t dir;
	DirectionAtoB( a, b, &dir );
	VectorToPolar( &dir, angle );
	return VectorNorm( &dir );
}
//�����l�F�\���̂ւ̃|�C���^�������Ƃ��Ă���
void MoveObject( ObjDataT *obj )
{
	obj->yaw += obj->turn;
	obj->x -= obj->move * sinf( obj->yaw * RADIAN );
	obj->z -= obj->move * cosf( obj->yaw * RADIAN );
	obj->y += obj->UpDown;// *sinf(obj->pitch * RADIAN) + obj->UpDown * cosf(obj->yaw * RADIAN);; ///// y�����̈ړ����l������ꍇ
	//obj->y += obj->move * sinf(obj->pitch * RADIAN) -obj->UpDown * sinf(obj->yaw * RADIAN);
	//obj->y += obj->UpDown * sinf(obj->pitch * RADIAN);
}
//�����̓��m�̋����Ɋ�Â��ďՓ˂��������`�F�b�N����֐�
bool HitTest( ObjDataT *a, ObjDataT *b )
{
	if( DistanceAtoB( a, b ) < a->radius + b->radius ) return true;
	else return false;
}

//====================================================================================================
//�����������֐�
//�ŏ��lmin�ƍő�lmax�̊Ԃ̒l�������_���ɕԂ�
float uniformRandom( float min, float max ){
    double r;
    r = (double)rand()/(double)RAND_MAX;
    r = r * ( max - min ) + min;
    return r;
}
//���ȈՃK�E�X�m�C�Y�֐�
float gaussianRandom( float rmin, float rmax ){
    int i;
	float r = 0.0;
	const int n = 12;
	for( i = 0; i < n; i++ ){
		r += uniformRandom( rmin, rmax );
	}
	return r / n;
}
#if 0
//-------------���W�n�K�w�\������֐�
bool isHit( ObjDataT *a, ObjDataT *b )
{
	ObjDataT a_world, b_world;

	copyObj( a, &a_world );
	copyObj( b, &b_world );
	moveLocalToWorld( &a_world );
	moveLocalToWorld( &b_world );

	return HitTest( &a_world, &b_world );
}
// setObjLocal
void setObjLocal( ObjDataT *target, ObjDataT *base )
{
	target->base = base;
	return;
}
// setObjWorld
void setObjWorld( ObjDataT *target )
{
	target->base = NULL;
	return;
}
void moveLocalToWorld( ObjDataT *target )
{
	ObjDataT *base;
	base = target->base;
	while( base != NULL ){
		TransformLocalToWorld( base, target, target );
		base = base->base;
		setObjLocal( target, base );
	}
	setObjWorld( target );
	return;
}
void moveWorldToLocal( ObjDataT *target, ObjDataT *base )
{
	ObjDataT *b, world;

	b = base->base;
	if( b != NULL ){
		world.x = base->x;
		world.y = base->y;
		world.z = base->z;
		world.roll = base->roll;
		world.pitch = base->pitch;
		world.yaw = base->yaw;
		world.base = base->base;
		moveLocalToWorld( &world );
	}
	TransformWorldToLocal( &world, target, target );
	setObjLocal( target, base );
	return;
}
//----------------------------------- LocalToWorld
void TransformLocalToWorld( ObjDataT *base, ObjDataT *local, ObjDataT *world )
{
	//ObjDataT hand, target;
	float base_pos[3], base_rot[3], local_pos[3], local_rot[3];
	float world_pos[3], world_rot[3];

	base_pos[0] = base->x;
	base_pos[1] = base->y;
	base_pos[2] = base->z;
	base_rot[0] = base->roll;
	base_rot[1] = base->pitch;
	base_rot[2] = base->yaw;

	local_pos[0] = local->x;
	local_pos[1] = local->y;
	local_pos[2] = local->z;
	local_rot[0] = local->roll;
	local_rot[1] = local->pitch;
	local_rot[2] = local->yaw;

	ezUtil_Mult( base_pos, base_rot, local_pos, local_rot, world_pos, world_rot );

	world->x = world_pos[0];
	world->y = world_pos[1];
	world->z = world_pos[2];
	world->roll = world_rot[0];
	world->pitch = world_rot[1];
	world->yaw = world_rot[2];
}

void TransformWorldToLocal( ObjDataT *base, ObjDataT *target, ObjDataT *local )
{

	float matrix[16];

	glPushMatrix();
	glLoadIdentity();
	glRotatef( - base->roll, 0.0, 0.0, 0.0 );
	glRotatef( - base->pitch, 1.0, 0.0, 0.0 );
	glRotatef( - base->yaw, 0.0, 1.0, 0.0 );
	glTranslatef( - base->x,
			- base->y,
			- base->z );

	glTranslatef( target->x, target->y, target->z );
	glRotatef( target->yaw, 0.0, 1.0, 0.0 );
	glRotatef( target->pitch, 1.0, 0.0, 0.0 );
	glRotatef( target->roll, 0.0, 0.0, 1.0 );
	glGetFloatv( GL_MODELVIEW_MATRIX, matrix );
	glPopMatrix();

	float rot[3],pos[3];
	ezUtil_getRot( matrix, rot );
	ezUtil_getPos( matrix, pos );
	local->x = pos[0];
	local->y = pos[1];
	local->z = pos[2];
	local->roll = rot[0];
	local->pitch = rot[1];
	local->yaw = rot[2];

	return;
}
#endif