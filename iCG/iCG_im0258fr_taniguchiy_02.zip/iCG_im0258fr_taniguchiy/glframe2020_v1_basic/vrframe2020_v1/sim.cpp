#include "platform.h"

#include "common.h"
#include "sim.h"
#include "calc.h"

SimDataT simdata;
extern int time;

/*---------------------------------------------------------------- InitScene
 * InitScene:
 *--------*/
void InitScene( void )
{
	//�N���b�s���O�͈͂̐ݒ�
	simdata.clip_far = 100.0;
	simdata.clip_near = 0.1;
	//�w�i�F
	simdata.sky_color[0] = 0.0;
	simdata.sky_color[1] = 0.0;
	simdata.sky_color[2] = 0.0;
	//////

	//setObjPos( &simdata.cube, 0.0, 0.0, 20.0 );
	//setObjRot( &simdata.cube, 0.0, 0.0, 0.0 );
	//setObjColor( &simdata.cube, 1.0, 1.0, 0.0 );

	//setObjPos( &simdata.sphere, -1.0, 0.0, 5.0 );
	//setObjRot( &simdata.sphere, 0.0, 0.0, 0.0 );
	//setObjColor( &simdata.sphere, 1.0, 1.0, 1.0 );
	//simdata.sphere.radius = 0.5;

	//setObjPos(&simdata.cone, 0.0, 0.0, -7.0);
	//setObjRot(&simdata.cone, 0.0, 0.0, 0.0);
	//setObjColor(&simdata.cone, 1.0, 1.0, 1.0);

	setObjPos( &simdata.player, 0.0, 0.0, 30.0 );
	setObjRot( &simdata.player, 0.0, 0.0, 0.0 );
	setObjColor( &simdata.player, 0, 0.5,1.0 );

	setObjPos(&simdata.planet_01, 0.0, 0.0, 0.0);//sun
	setObjRot(&simdata.planet_01, 0.0, 0.0, 0.0);
	setObjColor(&simdata.planet_01, 1.0, 0.0, 0.0);

	setObjPos(&simdata.planet_02, 30.0, 0.0, 0.0);//earth
	setObjRot(&simdata.planet_02, 0.0, 0.0, 0.0);
	setObjColor(&simdata.planet_02, 0, 0.5, 1.0);

	setObjPos(&simdata.planet_03, 40.0, 0.0, 0.0);//mob02
	setObjRot(&simdata.planet_03, 0.0, 0.0, 0.0);
	setObjColor(&simdata.planet_03, 0, 1.0, 0.0);

	setObjPos(&simdata.planet_04, 20.0, 0.0, 0.0);//mob01
	setObjRot(&simdata.planet_04, 0.0, 0.0, 0.0);
	setObjColor(&simdata.planet_04, 1.0, 0.0, 1.0);

	setObjPos(&simdata.planet_05, 30.0, 0.0, 0.0);//moon
	setObjRot(&simdata.planet_05, 0.0, 0.0, 0.0);
	setObjColor(&simdata.planet_05, 1.0, 1.0, 1.0);

	setObjPos(&simdata.planet_06, 50.0, 0.0, 0.0);//mob03
	setObjRot(&simdata.planet_06, 0.0, 0.0, 0.0);
	setObjColor(&simdata.planet_06, 0, 1.0, 1.0);

	setObjColor(&simdata.bullet, 1.0, 1.0, 0.0);

	simdata.player.visible = true;
	simdata.player.state = 0;
	simdata.player.radius = 0.5;

	simdata.player.move = 0;
	simdata.player.turn = 0;

	simdata.player.UpDown = 0;

	simdata.cube.move = 0;
	simdata.cube.turn = 0;

	//simdata.sphere.move = 0;
	//simdata.sphere.turn = 0;

	simdata.active_camera = &simdata.player;

	simdata.bullet.visible = false;
	simdata.bullet.state = 0;

	simdata.bullet.radius = 0.5;
	simdata.planet_01.radius = 5.0;
	simdata.planet_02.radius = 3.0;
	simdata.planet_03.radius = 3.0;
	simdata.planet_04.radius = 3.0;
	simdata.planet_05.radius = 2.0;
	simdata.planet_06.radius = 3.0;

	simdata.bullet.sc = 0;

	//simdata.bullet.move = 0;
	//simdata.bullet.turn = 0;

	//�G�̃I�u�W�F�N�g�̕��z�͈͂��w��
	//float xrange = 50.0;
	//float zrange = 50.0;
	//for (int i = 0; i < N_ENEMIES; i++) {
		//setObjPos( &simdata.enemy[i], uniformRandom(-xrange, xrange), 0.0, uniformRandom(-zrange, zrange));
		//setObjRot(&simdata.enemy[i], 0.0, 0.0, uniformRandom(-180.0, 180.0));
		//simdata.enemy[i].state = 0;
		//simdata.enemy[i].visible = true;
		//setObjColor(&simdata.enemy[i], 0.8, 0.4, 0.2);
		//	�ړ����x�A���񑬓x��0
		//simdata.enemy[i].move = 0.0;
		//simdata.enemy[i].turn = 0.0;

		//simdata.enemy[i].radius = 0.5;
	//}

	//for (int i = 0; i < N_BLOCKS; i++) {
		//setObjPos(&simdata.block[i], uniformRandom(-xrange, xrange), 0.0, uniformRandom(-zrange, zrange));
		//setObjRot(&simdata.block[i], 0.0, 0.0, uniformRandom(-180.0, 180.0));
		//imdata.block[i].state = 0;
		//simdata.block[i].visible = true;
		//setObjColor(&simdata.block[i], 0.2, 0.8, 0.5);
		//	�ړ����x�A���񑬓x��0
		//simdata.block[i].move = 0.0;
		//simdata.block[i].turn = 0.0;
	//}

	float xrange = 50.0;
	float yrange = 50.0;
	float zrange = 50.0;

	for (int i = 0; i < N_STARS; i++)

	{

		simdata.star[i].x = uniformRandom(-xrange, xrange);

		simdata.star[i].y = uniformRandom(-yrange, yrange);

		simdata.star[i].z = uniformRandom(-zrange, zrange);

		simdata.star[i].roll = uniformRandom(-180.0, 180.0);

		simdata.star[i].pitch = uniformRandom(-180.0, 180.0);

		simdata.star[i].yaw = uniformRandom(-180.0, 180.0);

		//��ԕϐ��͂Ƃ肠����0

		simdata.star[i].state = 0;

		//�������͂ЂƂ܂���

		simdata.star[i].visible = true;

		//�F�͂��D�݂�

		simdata.star[i].red = 1.0;

		simdata.star[i].green = 1.0;

		simdata.star[i].blue = 1.0;

		//�ړ����x�A���񑬓x��0

		simdata.star[i].move = 0.0;

		simdata.star[i].turn = 0.0;

	}

    return;

}
/*-------------------------------------------------------------- UpdateScene
 * UpdateScene:
 *--------*/
void UpdateScene(void)
{
	//////// �f�[�^�X�V ////////
	//switch (simdata.planet_03.state) {
	//case 0:
	//	simdata.planet_03.x += 00.3;
	//	simdata.planet_03.y += 00.3;

	//	break;
	//}
	//switch (simdata.cube.state) {
	//case 0: //���0�ŐÎ~
		//if(HitTest(&simdata.cube, &simdata.player)) {
			//simdata.cube.state = 1;
			//setObjColor(&simdata.cube, 1.0, 0.0, 0.0);
		//}
		//break;
	//case 1: //���1�ŏ㏸q
		//simdata.cube.y += 0.05;
		//simdata.cube.x += 0.1;
		//simdata.cube.yaw += 1.0;
		//if (simdata.cube.y > 1.0) {
			//simdata.cube.state = 2;
			//setObjColor(&simdata.cube, 0.0, 0.0, 1.0);
		//}
		//break;
	//case 2:
		//simdata.cube.y += 0.1;
		//simdata.cube.x -= 0.1;
		//simdata.cube.yaw += 5.0;
		//if (simdata.cube.x < 0.0) {
			//simdata.cube.state = 3;
			//setObjColor(&simdata.cube, 0.0, 0.0, 1.0);
		//}
		//break;
	//case 3:
		//simdata.cube.x -= 0.1;
	//	simdata.cube.y -= 0.1;
	//	simdata.cube.yaw += 5.0;
	//	if (simdata.cube.y < 1.0) {
	//		simdata.cube.state = 4;
	//		setObjColor(&simdata.cube, 1.0, 0.0, 0.0);
	//	}
	//	break;
	//case 4:
	//	simdata.cube.y -= 0.05;
	//	simdata.cube.x += 0.1;
	//	simdata.cube.yaw += 5.0;
	//	if (simdata.cube.y < 0.0) {
	//		simdata.cube.state = 5;
	//		setObjColor(&simdata.cube, 0.0, 1.0, 0.0);
	//	}
	//	break;
	//case 5:
	//	simdata.cube.x += 0.1;
	//	simdata.cube.yaw += 5.0;
	//	if (simdata.cube.x > 1.0) {
	//		simdata.cube.state = 1;
	//		setObjColor(&simdata.cube, 0.0, 0.0, 0.0);
	//	}
	//	break;
	//}

	MoveObject(&simdata.player);

	//float dist; //player��sphere�Ƃ̊Ԃ̋���
	//euler_t angle; //sphere���猩��player�̕��p
	float k_move = -0.1; //���x�p�����[�^

	//dist = EulerAtoB(&simdata.sphere, &simdata.player, &angle);

	//if (dist < 10.0) {
		//simdata.sphere.move = k_move;
		//simdata.sphere.turn = 0.0;
		//simdata.sphere.yaw = angle.yaw;
		//simdata.sphere.yaw = angle.yaw + 180.0;
	//}

	//if (HitTest(&simdata.sphere, &simdata.player)) {
		//simdata.sphere.move =  simdata.sphere.move *100;
		//simdata.sphere.turn = 0.0;
		//simdata.sphere.yaw = angle.yaw;
	//}
	//else {
		//simdata.sphere.move += 0.05;
		//if (simdata.sphere.move > 0.0) {
			//simdata.sphere.move = 0.0;
		//}
	//}
	//MoveObject(&simdata.sphere);

	//for (int i = 0; i < N_ENEMIES; i++) {
		//float dist;
		//euler_t angle;
		//float k_move = 0.01;
		//dist = EulerAtoB(&simdata.enemy[i], &simdata.player, &angle);
		//simdata.enemy[i].move = k_move;
		//simdata.enemy[i].turn = 0.0;
		//simdata.enemy[i].yaw = angle.yaw;

		//switch (simdata.enemy[i].state) {
		//case 0:
			//if (HitTest(&simdata.enemy[i], &simdata.player)) {
				//simdata.enemy[i].state = 1;
				//setObjColor(&simdata.enemy[i], 1.0, 0.0, 0.0);
			//}
			//break;
		//case 1:
			//simdata.enemy[i].y += 5.0;
		//}

		//MoveObject(&simdata.enemy[i]);
	//}

	//MoveObject(&simdata.player);

	//for (int i = 0; i < N_BLOCKS; i++) {

		//switch (simdata.block[i].state) {
		//case 0:
			//if (HitTest(&simdata.block[i], &simdata.player)) {
				//simdata.player.move = -0.1;
			//}
			//break;
		//}

		//MoveObject(&simdata.block[i]);
	//}
		////////

		//if (HitTest(&simdata.player, &simdata.sphere)) {
			//setObjColor(&simdata.sphere, 1.0, 0.0, 0.0);
			//setObjColor(&simdata.cube, 1.0, 1.0, 0.0);
		//}
		//return;

	switch (simdata.bullet.state) {

	case 0:

		break;

	case 1:

		//���ʒu�̍X�V

		MoveObject(&simdata.bullet);

		//���Փ˔���

		if (HitTest(&simdata.bullet, &simdata.planet_01)) { //�������ځF�U���Ώ�

			setObjColor(&simdata.planet_01, 1.0, 1.0, 0.0);

			simdata.bullet.sc = simdata.bullet.sc + 1;

			simdata.bullet.state = 2; //���e�Ɉڍs

			//simdata.planet_01.state = 1;

		}

		if (DistanceAtoB(&simdata.bullet, &simdata.planet_01) > 100.0) {

			simdata.bullet.state = 0; //�e������ĉ����܂Ō������烊�Z�b�g

		}



		if (HitTest(&simdata.bullet, &simdata.planet_02)) { //�������ځF�U���Ώ�

			setObjColor(&simdata.planet_02, 1.0, 1.0, 0.0);

			simdata.bullet.sc = simdata.bullet.sc + 1;

			simdata.bullet.state = 2; //���e�Ɉڍs

			//simdata.planet_02.state = 1;

		}

		if (DistanceAtoB(&simdata.bullet, &simdata.planet_02) > 100.0) {

			simdata.bullet.state = 0; //�e������ĉ����܂Ō������烊�Z�b�g

		}



		if (HitTest(&simdata.bullet, &simdata.planet_03)) { //�������ځF�U���Ώ�

			setObjColor(&simdata.planet_03, 1.0, 1.0, 0.0);

			simdata.bullet.sc = simdata.bullet.sc + 1;

			simdata.bullet.state = 2; //���e�Ɉڍs

			//simdata.planet_03.state = 1;

		}

		if (DistanceAtoB(&simdata.bullet, &simdata.planet_03) > 100.0) {

			simdata.bullet.state = 0; //�e������ĉ����܂Ō������烊�Z�b�g

		}



		if (HitTest(&simdata.bullet, &simdata.planet_04)) { //�������ځF�U���Ώ�

			setObjColor(&simdata.planet_04, 1.0, 1.0, 0.0);

			simdata.bullet.sc = simdata.bullet.sc + 1;

			simdata.bullet.state = 2; //���e�Ɉڍs

			//simdata.planet_04.state = 1;

		}

		if (DistanceAtoB(&simdata.bullet, &simdata.planet_04) > 100.0) {

			simdata.bullet.state = 0; //�e������ĉ����܂Ō������烊�Z�b�g

		}



		if (HitTest(&simdata.bullet, &simdata.planet_05)) { //�������ځF�U���Ώ�

			setObjColor(&simdata.planet_05, 1.0, 1.0, 0.0);

			simdata.bullet.sc = simdata.bullet.sc + 1;

			simdata.bullet.state = 2; //���e�Ɉڍs

			//simdata.planet_05.state = 1;

		}

		if (DistanceAtoB(&simdata.bullet, &simdata.planet_05) > 100.0) {

			simdata.bullet.state = 0; //�e������ĉ����܂Ō������烊�Z�b�g

		}



		if (HitTest(&simdata.bullet, &simdata.planet_06)) { //�������ځF�U���Ώ�

			setObjColor(&simdata.planet_06, 1.0, 1.0, 0.0);

			simdata.bullet.sc = simdata.bullet.sc + 1;

			simdata.bullet.state = 2; //���e�Ɉڍs

			//simdata.planet_06.state = 1;

		}

		if (DistanceAtoB(&simdata.bullet, &simdata.planet_06) > 100.0) {

			simdata.bullet.state = 0; //�e������ĉ����܂Ō������烊�Z�b�g

		}

		break;

	case 2:

		simdata.bullet.state = 0; //�ȒP�̂��߁A���e�㏉����Ԃɕ��A

		break;

	}

	switch (simdata.planet_02.state) {
	case 0:
		simdata.planet_02.x -= 0.1;
		simdata.planet_02.z += 0.1;
		if (simdata.planet_02.x < 0.0) {
			simdata.planet_02.state = 1;

		}
		break;

	case 1:
		simdata.planet_02.x -= 0.1;
		simdata.planet_02.z -= 0.1;
		if (simdata.planet_02.x < -30.0) {
			simdata.planet_02.state = 2;
		}
		break;

	case 2:
		simdata.planet_02.x += 0.1;
		simdata.planet_02.z -= 0.1;
		if (simdata.planet_02.x > 0.0) {
			simdata.planet_02.state = 3;
		}
		break;

	case 3:
		simdata.planet_02.x += 0.1;
		simdata.planet_02.z += 0.1;
		if (simdata.planet_02.x > 30.0) {
			simdata.planet_02.state = 0;
		}
		break;
	}


	switch (simdata.planet_03.state) {
	case 0:
		simdata.planet_03.x -= 0.1;
		simdata.planet_03.z += 0.1;
		simdata.planet_03.y += 0.03;
		if (simdata.planet_03.x < 0.0) {
			simdata.planet_03.state = 1;

		}
		break;

	case 1:
		simdata.planet_03.x -= 0.1;
		simdata.planet_03.z -= 0.1;
		simdata.planet_03.y += 0.03;
		if (simdata.planet_03.x < -40.0) {
			simdata.planet_03.state = 2;
		}
		break;

	case 2:
		simdata.planet_03.x += 0.1;
		simdata.planet_03.z -= 0.1;
		simdata.planet_03.y -= 0.03;
		if (simdata.planet_03.x > 0.0) {
			simdata.planet_03.state = 3;
		}
		break;

	case 3:
		simdata.planet_03.x += 0.1;
		simdata.planet_03.z += 0.1;
		simdata.planet_03.y -= 0.03;
		if (simdata.planet_03.x > 40.0) {
			simdata.planet_03.state = 0;
		}
		break;
	}

	switch (simdata.planet_04.state) {
	case 0:
		simdata.planet_04.x -= 0.1;
		simdata.planet_04.z += 0.1;
		simdata.planet_04.y -= 0.01;
		if (simdata.planet_04.x < 0.0) {
			simdata.planet_04.state = 1;

		}
		break;

	case 1:
		simdata.planet_04.x -= 0.1;
		simdata.planet_04.z -= 0.1;
		simdata.planet_04.y -= 0.01;
		if (simdata.planet_04.x < -20.0) {
			simdata.planet_04.state = 2;
		}
		break;

	case 2:
		simdata.planet_04.x += 0.1;
		simdata.planet_04.z -= 0.1;
		simdata.planet_04.y += 0.01;
		if (simdata.planet_04.x > 0.0) {
			simdata.planet_04.state = 3;
		}
		break;

	case 3:
		simdata.planet_04.x += 0.1;
		simdata.planet_04.z += 0.1;
		simdata.planet_04.y += 0.01;
		if (simdata.planet_04.x > 20.0) {
			simdata.planet_04.state = 0;
		}
		break;
	}

	switch (simdata.planet_06.state) {
	case 0:
		simdata.planet_06.x -= 0.1;
		simdata.planet_06.z += 0.1;
		simdata.planet_06.y -= 0.03;
		if (simdata.planet_06.x < 0.0) {
			simdata.planet_06.state = 1;

		}
		break;

	case 1:
		simdata.planet_06.x -= 0.1;
		simdata.planet_06.z -= 0.1;
		simdata.planet_06.y += 0.03;
		if (simdata.planet_06.x < -50.0) {
			simdata.planet_06.state = 2;
		}
		break;

	case 2:
		simdata.planet_06.x += 0.1;
		simdata.planet_06.z -= 0.1;
		simdata.planet_06.y += 0.03;
		if (simdata.planet_06.x > 0.0) {
			simdata.planet_06.state = 3;
		}
		break;

	case 3:
		simdata.planet_06.x += 0.1;
		simdata.planet_06.z += 0.1;
		simdata.planet_06.y -= 0.03;
		if (simdata.planet_06.x > 50.0) {
			simdata.planet_06.state = 0;
		}
		break;
	}

	float x_moon = simdata.planet_02.x;
	float y_moon = simdata.planet_02.y;
	float z_moon = simdata.planet_02.z;


	float radius = 5.0f;
	float angle = 0.5f; // ���W�A���P��
	float speed = 0.01f; // ��]���x

	simdata.planet_05.x = radius * cos(angle) + x_moon;
	simdata.planet_05.z = radius * sin(angle) + z_moon;

	//switch (simdata.planet_05.state) {
	//case 0:
	//	simdata.planet_05.x = x_moon + 5.0;
	//	simdata.planet_05.z = z_moon ;
	//	simdata.planet_05.y += 0.1;
	//	if (simdata.planet_05.y > 5.0) {
	//		simdata.planet_05.state = 1;
	//	}
	//	break;
	//case 1:
	//	simdata.planet_05.y = y_moon + 5.0;
	//	simdata.planet_05.z = z_moon;

	//	simdata.planet_05.z -= 0.1;
	//break;

	//}



	if (HitTest(&simdata.player, &simdata.planet_01)) { 

		exit(0);
		//sc + 1;
	}

	if (HitTest(&simdata.player, &simdata.planet_02)) {

		exit(0);
		//sc + 1;

	}

	if (HitTest(&simdata.player, &simdata.planet_03)) {

		exit(0);
		//sc + 1;

	}

	if (HitTest(&simdata.player, &simdata.planet_04)) {

		exit(0);
		//sc + 1;

	}

	if (HitTest(&simdata.player, &simdata.planet_05)) {

		exit(0);
		//sc + 1;

	}

	if (HitTest(&simdata.player, &simdata.planet_06)) {

		exit(0);
		//sc + 1;

	}
}