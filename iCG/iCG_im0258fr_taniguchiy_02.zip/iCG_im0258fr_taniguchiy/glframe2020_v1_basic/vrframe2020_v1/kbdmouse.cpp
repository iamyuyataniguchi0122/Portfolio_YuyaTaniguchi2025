/******************************************************************************
 * keybdmouse.cpp: keyboard and mouse callback functions 
 */
#include "platform.h"

#include "common.h"

#include "sim.h"
#include "calc.h"
extern SimDataT simdata;
extern WindowDataT window;


static float mouseX0, mouseY0;//�O�X��̃}�E�X���K�����W�i-1����1�܂ł̒l���Ƃ�j

static float mouseX1, mouseY1;//�O��̃}�E�X���K�����W

static float mousedX, mousedY; //�ړ���

static void mousePosition(int x, int y)

{

    mouseX0 = mouseX1;

    mouseY0 = mouseY1;

    mouseX1 = (float)x / window.width * 2.0 - 1.0; //normalize x position

    mouseY1 = (float)y / window.height * 2.0 - 1.0; //normalize y position

    mousedX = mouseX1 - mouseX0;

    mousedY = mouseY1 - mouseY0;

}



//-------- modifier key status
bool isShiftKeyDown( void );
bool isCtrlKeyDown( void );
bool isAltKeyDown( void );

/*-------------------------------------------------- modifier key status
 * Shift, Ctrl, Alt key status
 */
bool isShiftKeyDown( void )
{ return (bool)(glutGetModifiers() & GLUT_ACTIVE_SHIFT); }
bool isCtrlKeyDown( void )
{ return (bool)(glutGetModifiers() & GLUT_ACTIVE_CTRL); }
bool isAltKeyDown( void )
{ return (bool)(glutGetModifiers() & GLUT_ACTIVE_ALT); }





/*------------------------------------------------------------- charKeyDown/Up
 * charKeyDown/Up - GLUT keyboard callback function
 * key: ASCII code
 * x, y: mouse position
 *--------*/
void charKeyDown( unsigned char key, int x, int y )
{
    switch( key ){
      case 'h': // help
        printf( "Instruction\n" );
        printf( "[H]:Help\n" );
        printf( "[Q]:Quit\n" );
        break;

      //case 'q': // quit
      //  exit(0);
      //  break;

      case'a':
      //    //simdata.player.x -= 0.1;
          simdata.player.turn = 0.5;
          break;

      case's':
          //simdata.player.UpDown = -0.3;
          simdata.player.move = -0.1;
          break;

      case'd':
      //    //simdata.player.z -= 0.1;
          simdata.player.turn = -0.5;
          break;

      case'w':
          simdata.player.move = 0.1;
          break;

      case'b':
          simdata.player.UpDown = 0.3;
          //simdata.player.move = 0.1;
          break;

      case'v':
          simdata.player.UpDown = -0.3;
          break;

      case ' ': //���e�۔���

          printf("////FIRE////\n");

          simdata.bullet.state = 1; //���ˏ�ԂɑJ��

          simdata.bullet.move = 1.0; //�e���w�� �����߂���Ƃ��蔲���܂�

          simdata.bullet.x = simdata.player.x;

          simdata.bullet.y = simdata.player.y + 0.0; //���ˍ�������

          simdata.bullet.z = simdata.player.z;

          simdata.bullet.yaw = simdata.player.yaw; //���ˎ�̂̕�����e�ۂɐݒ�



          break;
    }
    return;
}
void charKeyUp( unsigned char key, int x, int y )
{
    switch( key ){
    case'a':
  //      //simdata.player.x -= 0.1;
        simdata.player.turn = 0.0;
        break;
    case's':
        //simdata.player.UpDown = 0.0;
        simdata.player.move = 0.0;
        break;
    case'd':
  //      //simdata.player.z -= 0.1;
        simdata.player.turn = 0.;
        break;
    case'w':
        //simdata.player.UpDown = 0.0;
        simdata.player.move = 0.0;
		break;
    case'b':
        simdata.player.UpDown = 0.0;
            break;
    case'v':
        simdata.player.UpDown = 0.0;
        break;

  //  default:
        break;
	}
}
/*--------------------------------------------------------------- funcKeyDown/Up
 * funcKeyDown/Up - GLUT special key callback
 * key: GLUT key code
 * x, y: mouse position
 */
void funcKeyDown( int key, int x, int y )
{
	//�t�@���N�V�����L�[
	//[F*]: GLUT_KEY_F*(*��1�`12)
	//[F1]: GLUT_KEY_F1
	//[F12]:GLUT_KEY_F12
	//���̑��̋@�\�L�[
    //[PageUp]  : GLUT_KEY_PAGE_UP:
    //[PageDown]: GLUT_KEY_PAGE_DOWN:
    //[Home]    : GLUT_KEY_HOME:
    //[End]     : GLUT_KEY_END:
    //[Insert]  : GLUT_KEY_INSERT:

	//�J�[�\���L�[
	switch( key ){
	  case GLUT_KEY_LEFT: //[��]

		break;
  	  case GLUT_KEY_RIGHT://[��]

		break;
	  case GLUT_KEY_UP: //[��]

		break;
	  case GLUT_KEY_DOWN://[��]

		break;
	}
}
void funcKeyUp( int key, int x, int y )
{
	switch( key ){
	  case GLUT_KEY_LEFT: //[��]

		break;
  	  case GLUT_KEY_RIGHT://[��]

		break;
	  case GLUT_KEY_UP: //[��]

		break;
	  case GLUT_KEY_DOWN://[��]

		break;
	}
}
/*------------------------------------------------------------- mouseClick
 * mouseClick - GLUT mouse callback function
 * button: mouse button
 * state�Fpress or release
 * x, y�Fmouse position
 *--------*/
void mouseClick( int button , int state, int x, int y )
{
    switch( button ){
      case GLUT_LEFT_BUTTON:
        switch( state ){
          case GLUT_DOWN: // press
              mousePosition(x, y);
              mousePosition(x, y);
            break;
          case GLUT_UP: // release
              simdata.player.turn = 0;
              simdata.player.move = 0;
            break;
          default:
            break;
        }
        break;
      case GLUT_MIDDLE_BUTTON:
        switch( state ){
          case GLUT_DOWN: // press

            break;
          case GLUT_UP: // release

            break;
          default:
            break;
        }
        break;
      case GLUT_RIGHT_BUTTON:
        switch( state ){
          case GLUT_DOWN: // press

            break;
          case GLUT_UP: // release

            break;
          default:
            break;
        }
        break;
      default:
        break;
    }
    return;
}
/*---------------------------------------------------------------- mouseDrag 
 * mouseDrag - mouse drag callback function
 */
void mouseDrag( int x, int y )
{
	////////
    mousePosition(x, y);

    simdata.player.turn += -mousedX; //�}�C�i�X�����������Ƃɒ���

    simdata.player.move += -mousedY; //�}�C�i�X�����������Ƃɒ���

	////////
    return;
}
/*-------------------------------------------------------------- mouseMotion
 * mouseMotion - passive mouse motion callback function
 */
void mouseMotion( int x, int y )
{
	////////


	////////
    return;
}