#include "platform.h"
#include "GLMetaseq.h"

#include "sim.h"
#include "mymodel.h"

static MQO_MODEL mymodel1;
static MQO_MODEL mymodel2;

//���ǉ����郂�f���p�̕ϐ���ǉ�����
static MQO_MODEL chicken;

static GLuint globj_block;
static GLuint globj_stars;

void applyMaterialColor( float r, float g, float b );

void makeRandomBlocks( int n )
{
	globj_block = glGenLists( 1 );
    glNewList(  globj_block, GL_COMPILE );

	for( int i = 0; i<n; i++ ){
		// draw one object
	}

	glEndList();
}

//-------------------------------------------------------------------- makeStars
/* makeStars:
 */
void makeStars( int n, float x_range, float y_range, float z_range )
{
    globj_stars = glGenLists( 1 );
    glNewList( globj_stars, GL_COMPILE );
	glShadeModel( GL_FLAT );
    int i;
    float x, y, z;
    //glColor3f( 1.0, 1.0, 1.0 );
	applyMaterialColor( 0.8, 0.8, 0.8 );
    //glPointSize( 2.0 );
    //glBegin( GL_POINTS );
    for( i = 0; i < n; i++ ){
        x = x_range * (float)rand()/(float)RAND_MAX - x_range / 2.0;
        y = y_range * (float)rand()/(float)RAND_MAX - y_range / 2.0;
        z = z_range * (float)rand()/(float)RAND_MAX - z_range / 2.0;
		glPushMatrix();
		glTranslatef( x, y, z );
		glRotatef( 90.0, 1.0, 0.0, 0.0 );
		glutSolidSphere( 0.1, 8, 5 );
		glPopMatrix();
        //glVertex3f( x, y, z );
    }
    //glEnd();
    glEndList();
    return;
}
void makeStars( int n, float range )
{
	makeStars( n, range, range, range );
}
//-------------------------------------------------------------------- drawStars
/* drawStars: ����`�悷��
 */
void drawStars( void )
{
    glPushAttrib( GL_LIST_BIT );
    //glListBase( globj_stars );
    glCallList( globj_stars );
    glPopAttrib();
    return;
}
/////////////////////////// ���ʊ֐�
/*----------------------------------------------------- CreateMyModels
 * CreateMyModels
 */
void CreateMyModels()
{
    //mymodel1 = mqoCreateModel( "mymodel1.mqo", 1.0 );
    //mymodel2 = mqoCreateModel( "mymodel2.mqo", 1.0 );

	makeStars( 2000, 100, 10, 100 );

	//�����f���t�@�C���ǂݍ���
	chicken = mqoCreateModel( "data/full_body_chicken.mqo", 0.1 );
}

/*----------------------------------------------------- DeleteMyModels
 * DeleteMyModels
 */
void DeleteMyModels()
{
    mqoDeleteModel( mymodel1 );
    mqoDeleteModel( mymodel2 );
}
/////////////////////////// �ʂ̊֐�
/*------------------------------------------------------ DrawChicken
 */
void drawChicken()
{
    glPushMatrix();
    //glRotatef( 90.0, 1.0, 0.0, 0.0 );//���f���̍��W�������Ȃ�
    mqoCallModel( chicken );
    glPopMatrix();
}

/*------------------------------------------------------ DrawMymodel1
 */
void DrawMymodel1()
{
    glPushMatrix();
    glRotatef( 90.0, 1.0, 0.0, 0.0 );//���f���̍��W�������Ȃ�
    mqoCallModel( mymodel1 );
    glPopMatrix();
}
/*------------------------------------------------------ DreaMymodel2
 */
void DrawMymodel2()
{
    glPushMatrix();
    glRotatef( 90.0, 1.0, 0.0, 0.0 );//���f���̍��W�������Ȃ�
    mqoCallModel( mymodel2 );
    glPopMatrix();
}
